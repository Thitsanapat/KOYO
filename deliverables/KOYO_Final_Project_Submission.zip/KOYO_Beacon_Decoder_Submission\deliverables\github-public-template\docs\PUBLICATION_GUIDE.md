# GitHub Publication Guide

Publish only the generated `github-public/KOYO-Beacon-Decoder` directory. Do
not initialize or push the private workspace root: it contains local-only
material, and an existing Git history can preserve files even after deletion.

## Pre-Push Check

1. Confirm there are no OGG, WAV, KISS, raw data, unapproved office source
   documents, or local Grafana/InfluxDB runtime files. The allowlisted
   `KOYO_Real_Results.xlsx` evidence workbook is expected.
2. Search text files for private hostnames, credentials, source-document names,
   byte offsets, and unapproved telemetry mappings.
3. Open the final PDF and presentation once from the public directory.
4. Confirm the repository visibility and access policy with the project owner.
5. Choose an approved license. No license is included by default.

## Initialize and Push

Run these commands from `github-public/KOYO-Beacon-Decoder` only:

```powershell
git init
git add .
git status
git commit -m "Publish KOYO beacon decoder evidence"
git branch -M main
git remote add origin <GITHUB_REPOSITORY_URL>
git push -u origin main
```

Review `git status` before committing. The generated public directory is built
from an explicit allowlist, but the final publication decision remains with the
project owner.
